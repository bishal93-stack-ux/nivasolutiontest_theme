<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nivasolutiontesttheme
 */
?>
<footer class="cart-section">
            <div class="cart-table">
                <div class="cart-title">
                    <h4 style="font-size:2vw">Cart</h4>
                </div>

                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Product</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">Product Name<br><br><button type="button" class="btn btn-secondary">Coupon
                                    Code</button><button type="button" class="btn btn-secondary">Apply Coupon</button>
                            </th>
                            <td>Rs</td>
                            <td>
                                <div class="container">
                                    <div class="row">
                                        <h2>Simple Quantity increment buttons with Javascript </h2>
                                        <div class="col-lg-2">
                                            <div class="input-group">
                                                <span class="input-group-btn">
                                                    <button type="button"
                                                        class="quantity-left-minus btn btn-danger btn-number"
                                                        data-type="minus" data-field="">
                                                        <span class="glyphicon glyphicon-minus"></span>
                                                    </button>
                                                </span>
                                                <input type="text" id="quantity" name="quantity"
                                                    class="form-control input-number" value="10" min="1" max="100">
                                                <span class="input-group-btn">
                                                    <button type="button"
                                                        class="quantity-right-plus btn btn-success btn-number"
                                                        data-type="plus" data-field="">
                                                        <span class="glyphicon glyphicon-plus"></span>
                                                    </button>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>Total Price<br><br><button type="button" class="btn btn-secondary">Update Cart</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="row">
                    <div class="column" style="background-color:#ee9f87;">
                    </div>
                    <div class="column" style="background-color:#bbb;">
                        <div class="cart-name">
                            <h4>Cart Totals</h4>
                            <p>Sub total</p>
                            <p>Shipping</p>
                            <p>Total</p>
                            <div class="checkout-button">
                                <a href="#" title="Login/Signup" class="btn btn-secondary test-button"
                                    data-toggle="popover" data-placement="left" data-trigger="hover"
                                    data-content="&Continue as Guest">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </div>
        </footer>
    </div>
<?php wp_footer();?>
</body>

</html>
