
function stickyHeader() {
    var height = $(window).scrollTop();
    var header = $(".site-header");

    if (height > 60) {
        header.addClass("sticky");
    } else {
        header.removeClass("sticky");
    }
}

$(window).scroll(stickyHeader);
stickyHeader();
$('.banner_slider').slick({
    dots: true,
    infinite: true,
    autoplay:true,
    fade:true,
    speed: 300,
    slidesToShow: 1
});
$(".product-1").mouseenter(function () {
    $(".on-hover").css("visibility","visible");
});

$(".product-1").mouseleave(function () {
    $(".on-hover").css("visibility","hidden");
});
var quantitiy=0;
$('.quantity-right-plus').click(function(e){

    // Stop acting like a button
    e.preventDefault();
    // Get the field name
    var quantity = parseInt($('#quantity').val());

    // If is not undefined

    $('#quantity').val(quantity + 1);


    // Increment

});

$('.quantity-left-minus').click(function(e){
    // Stop acting like a button
    e.preventDefault();
    // Get the field name
    var quantity = parseInt($('#quantity').val());

    // If is not undefined

    // Increment
    if(quantity>0){
        $('#quantity').val(quantity - 1);
    }
});


$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

