<?php
get_header();
?>
        <main>
            <div class="banner_slider_wrap">
                <div class="banner_slider">
                    <img src="../../media/banner-bg-1.jpg" alt="site banner" width="1920" height="975" class="responsive">
                    <img src="../../media/home-banner-image.jpg" alt="site banner" width="1920" height="999" class="responsive">
                </div>
            </div>
            <section class="recent-products">
                <div class="section-title">
                    <h4 style="font-size:2vw">Recent Products</h4>
                </div>
                <div class="card">
                    <div class="product-1">
                        <p style="font-size:1.5vw" class="product-text">Product 1</p>
                        <div class="on-hover">
                            <i class="far fa-eye"></i>
                            <i class="fas fa-heart"></i>
                            <p id="add-to-cart">Add to cart</p>
                        </div>
                    </div>
                    <div class="product-2">
                        <p style="font-size:1.5vw" class="product-text">Product 2</p>
                        <div class="on-hover">
                            <i class="far fa-eye"></i>
                            <i class="fas fa-heart"></i>
                            <p id="add-to-cart">Add to cart</p>
                        </div>
                    </div>
                    <div class="product-3">
                        <p style="font-size:1.5vw" class="product-text">Product 3</p>
                        <div class="on-hover">
                            <i class="far fa-eye"></i>
                            <i class="fas fa-heart"></i>
                            <p id="add-to-cart">Add to cart</p>
                        </div>
                    </div>
                </div>
            </section>
            <section class="site-footer">
                <div class="footer-title">
                    <h4 style="font-size:2vw">Footer</h4>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm">
                            <a href="#">Contact us</a>
                        </div>
                        <div class="col-sm">
                            <a href="#">About us</a>
                        </div>
                        <div class="col-sm">
                            <a href="#">Quick Links</a>
                        </div>
                        <div class="col-sm">
                            <a href="#">Follow us</a>
                        </div>
                    </div>
                </div>

            </section>

        </main>
<?php get_footer(); ?>
