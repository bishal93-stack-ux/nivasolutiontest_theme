<?php
/**
 * NivasolutionTestTheme Engine Room.
 * This is where all Theme Functions runs.
 *
 * @package nivasolutiontesttheme
 */
if (!function_exists('nivasolutiontesttheme_test_setup')) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function nivasolutiontesttheme_test_setup()
	{
		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support('post-thumbnails');
		add_image_size( 'site-banner', 1920, 975, false ); // (cropped)

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(array(
			'nav-pri' => esc_html__('Primary', 'nivasolutiontesttheme'),
		));
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 100,
				'width'       => 40,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
		add_theme_support( 'custom-header' );
	}
endif;
add_action( 'after_setup_theme', 'nivasolutiontesttheme_test_setup' );
function add_additional_class_on_a($classes, $Event, $args)
{
	if (isset($args->add_a_class)) {
		$classes['class'] = $args->add_a_class;
	}
	return $classes;
}

add_filter('nav_menu_link_attributes', 'add_additional_class_on_a', 1, 3);
function add_additional_class_on_li($classes, $item, $args) {
	if(isset($args->add_li_class)) {
		$classes[] = $args->add_li_class;
	}
	return $classes;
}
add_filter('nav_menu_css_class', 'add_additional_class_on_li', 1, 3);
add_action( 'init', 'add_gallery_post_type' );
function add_gallery_post_type() {
	register_post_type( 'zm_gallery',
		array(
			'labels' => array(
				'name' => __( 'Gallery' ),
				'singular_name' => __( 'Gallery' ),
				'all_items' => __( 'All Images')
			),
			'public' => true,
			'has_archive' => false,
			'exclude_from_search' => true,
			'rewrite' => array('slug' => 'gallery-item'),
			'supports' => array( 'title', 'thumbnail' ),
			'menu_position' => 4,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'publicly_queryable'  => false,
			'query_var'           => false
		)
	);
}
function zm_get_backend_preview_thumb($post_ID) {
	$post_thumbnail_id = get_post_thumbnail_id($post_ID);
	if ($post_thumbnail_id) {
		$post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'thumbnail');
		return $post_thumbnail_img[0];
	}
}

function zm_preview_thumb_column_head($defaults) {
	$defaults['featured_image'] = 'Image';
	return $defaults;
}
add_filter('manage_posts_columns', 'zm_preview_thumb_column_head');

function zm_preview_thumb_column($column_name, $post_ID) {
	if ($column_name == 'featured_image') {
		$post_featured_image = zm_get_backend_preview_thumb($post_ID);
		if ($post_featured_image) {
			echo '<img src="' . $post_featured_image . '" />';
		}
	}
}
add_action('manage_posts_custom_column', 'zm_preview_thumb_column', 10, 2);
/**
 * Setup.
 * Enqueue styles, register widget regions, etc.
 */
require get_template_directory() . '/inc/functions/function-ss.php';



