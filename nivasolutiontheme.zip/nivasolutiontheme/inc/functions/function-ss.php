<?php

function nivasolutiontesttheme_styles(){
	$uri = get_theme_file_uri();
	wp_register_style('site-bootstrap',$uri.'/css/bootstrap.min.css',array(),null);
	wp_register_style('site-slick',$uri.'/slick/slick.css',array(),null);
	wp_register_style('site-all',$uri.'/css/all.min.css',array(),null);
	wp_enqueue_style( 'site-bootstrap');
	wp_enqueue_style( 'style', get_stylesheet_uri() );
	wp_enqueue_style( 'site-all' );
	wp_enqueue_style( 'site-slick' );
	wp_deregister_script('jquery');
	wp_register_script( 'jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jqueryexample.min.js');
	wp_register_script('nivasolution-jquery',$uri.'/js/jquery.min.js',array('jquery'),null,true);
	wp_register_script('nivasolution-popper',$uri.'/js/popper.min.js',array('jquery'),null,true);
	wp_register_script('nivasolution-bootstrap-js',$uri.'/js/bootstrap.min.js',array('jquery'),null,true);
	wp_register_script('nivasolution-slick-js',$uri.'/slick/slick.js',array('jquery'),null,true);
	wp_register_script('nivasolution-main',$uri.'/js/main.js',array('jquery'),null,true);
	wp_enqueue_script('jquery');
	wp_enqueue_script('nivasolution-jquery');
	wp_enqueue_script('nivasolution-popper');
	wp_enqueue_script('nivasolution-bootstrap-js');
	wp_enqueue_script('nivasolution-slick-js');
	wp_enqueue_script('nivasolution-main');
}

add_action('wp_enqueue_scripts', 'nivasolutiontesttheme_styles');
