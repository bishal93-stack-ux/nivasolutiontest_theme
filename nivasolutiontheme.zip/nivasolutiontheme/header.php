
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width" initial-scale="1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta http-equiv="author" content="Bishal GC" />
	<meta http-equiv="pragma" content="no-cache" />
	<?php wp_head();?>
</head>
<body>
<div class="site-wrapper">
	<header class="site-header">
		<nav class="navbar navbar-light navbar-expand-lg">
			<?php  $custom_logo_id = get_theme_mod( 'custom_logo' );
			$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
			?>
			<a class="navbar-brand" href="<?php echo home_url();?>"><img src="<?php echo $image[0];?>" alt="Logo"></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse"
			        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
			        aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Men</a>
					</li>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
						   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Woman
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							<a class="dropdown-item" href="#">Action</a>
							<a class="dropdown-item" href="#">Another action</a>
						</div>
					</li>
				</ul>
				<div class="icon header-right1">
					<i class="fas fa-user"></i>
					<i class="fas fa-heart"></i>
					<i class="fas fa-search"></i>
				</div>
			</div>
		</nav>
	</header>
