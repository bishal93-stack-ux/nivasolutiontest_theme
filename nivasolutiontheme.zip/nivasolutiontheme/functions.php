<?php
/**
 * Niva Solution functions and definitions
 *
 * @package nivasolutiontesttheme
 */
require get_template_directory() . '/inc/init.php';
